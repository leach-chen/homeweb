function diyfun() {
    alert("bbbbb")
}
export { 
    diyfun
}