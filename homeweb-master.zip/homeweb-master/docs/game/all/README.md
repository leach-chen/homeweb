# 全部
---

<ResourceItem/>


<style scoped>
.content:not(.custom) {
    max-width: 100%;
}
</style>